abstract class Observer {
    abstract void update(Subject subject);
}
