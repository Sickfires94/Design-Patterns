public enum Actions {
    nothing,
    add_money,
    select_item,
    cancel,
}
